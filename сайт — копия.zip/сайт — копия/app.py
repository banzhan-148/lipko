# -*- coding: utf-8 -*-
"""
АСУ «АвтоЗапчасти»
Автоматизированная система управления магазином автозапчастей и автотоваров.
Разработано по ГОСТ 34.601-90 и ГОСТ 34.602-89.
"""

import os
from datetime import datetime, timedelta
from functools import wraps

from flask import (Flask, render_template, request, redirect, url_for,flash, session)
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash

# ---------------------------------------------------------------------------
# Инициализация приложения
# ---------------------------------------------------------------------------
BASE_DIR = os.path.abspath(os.path.dirname(__file__))

app = Flask(__name__)
app.config['SECRET_KEY'] = 'avtozapchasti-secret-key-change-in-prod'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///' + os.path.join(BASE_DIR, 'avtozapchasti.db')
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)


# ---------------------------------------------------------------------------
# МОДЕЛИ ДАННЫХ (раздел 4.3.2 ТЗ)
# ---------------------------------------------------------------------------

class User(db.Model):
    __tablename__ = 'users'
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(64), unique=True, nullable=False)
    password_hash = db.Column(db.String(256), nullable=False)
    full_name = db.Column(db.String(128), nullable=False)
    role = db.Column(db.String(32), default='manager')
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)


class Category(db.Model):
    __tablename__ = 'categories'
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(128), nullable=False)


class Part(db.Model):
    __tablename__ = 'parts'
    id = db.Column(db.Integer, primary_key=True)
    article = db.Column(db.String(64), unique=True, nullable=False)
    catalog_number = db.Column(db.String(64))
    name = db.Column(db.String(256), nullable=False)
    manufacturer = db.Column(db.String(128))
    category_id = db.Column(db.Integer, db.ForeignKey('categories.id'))
    price = db.Column(db.Float, default=0.0)
    quantity = db.Column(db.Integer, default=0)
    min_quantity = db.Column(db.Integer, default=5)
    applicability = db.Column(db.String(256))
    analogs = db.Column(db.String(256))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    category = db.relationship('Category', backref='parts')


class Operation(db.Model):
    __tablename__ = 'operations'
    id = db.Column(db.Integer, primary_key=True)
    op_type = db.Column(db.String(32), nullable=False)
    part_id = db.Column(db.Integer, db.ForeignKey('parts.id'), nullable=False)
    quantity = db.Column(db.Integer, nullable=False)
    comment = db.Column(db.String(256))
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    part = db.relationship('Part')
    user = db.relationship('User')


class Customer(db.Model):
    __tablename__ = 'customers'
    id = db.Column(db.Integer, primary_key=True)
    full_name = db.Column(db.String(128), nullable=False)
    phone = db.Column(db.String(32))
    email = db.Column(db.String(128))
    debt = db.Column(db.Float, default=0.0)


class Order(db.Model):
    __tablename__ = 'orders'
    id = db.Column(db.Integer, primary_key=True)
    customer_id = db.Column(db.Integer, db.ForeignKey('customers.id'))
    status = db.Column(db.String(32), default='новый')
    total = db.Column(db.Float, default=0.0)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    customer = db.relationship('Customer')
    items = db.relationship('OrderItem', backref='order', cascade='all, delete-orphan')


class OrderItem(db.Model):
    __tablename__ = 'order_items'
    id = db.Column(db.Integer, primary_key=True)
    order_id = db.Column(db.Integer, db.ForeignKey('orders.id'))
    part_id = db.Column(db.Integer, db.ForeignKey('parts.id'))
    quantity = db.Column(db.Integer, default=1)
    price = db.Column(db.Float, default=0.0)

    part = db.relationship('Part')


# ---------------------------------------------------------------------------
# АУТЕНТИФИКАЦИЯ (раздел 4.1.9 ТЗ)
# ---------------------------------------------------------------------------

def login_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if not session.get('user_id'):
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated


def role_required(*roles):
    def wrapper(f):
        @wraps(f)
        def decorated(*args, **kwargs):
            if session.get('role') not in roles:
                flash('Недостаточно прав для выполнения операции', 'error')
                return redirect(url_for('index'))
            return f(*args, **kwargs)
        return decorated
    return wrapper


@app.context_processor
def inject_user():
    return {
        'current_user': session.get('full_name'),
        'current_role': session.get('role'),
    }


# ---------------------------------------------------------------------------
# МАРШРУТЫ
# ---------------------------------------------------------------------------

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form.get('username', '').strip()
        password = request.form.get('password', '')
        user = User.query.filter_by(username=username).first()
        if user and user.check_password(password):
            session['user_id'] = user.id
            session['full_name'] = user.full_name
            session['role'] = user.role
            flash(f'Добро пожаловать, {user.full_name}!', 'success')
            return redirect(url_for('index'))
        flash('Неверный логин или пароль', 'error')
    return render_template('login.html')


@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('login'))


@app.route('/')
@login_required
def index():
    stats = {
        'parts_count': Part.query.count(),
        'low_stock': Part.query.filter(Part.quantity <= Part.min_quantity).count(),
        'orders_active': Order.query.filter(Order.status != 'выдан').count(),
        'total_value': db.session.query(db.func.sum(Part.price * Part.quantity)).scalar() or 0.0,
    }
    recent_ops = Operation.query.order_by(Operation.created_at.desc()).limit(8).all()
    low_stock_parts = Part.query.filter(Part.quantity <= Part.min_quantity).limit(10).all()
    return render_template('index.html', stats=stats,
                           recent_ops=recent_ops,
                           low_stock_parts=low_stock_parts)


@app.route('/catalog')
@login_required
def catalog():
    q = request.args.get('q', '').strip()
    category_id = request.args.get('category', type=int)

    query = Part.query
    if q:
        query = query.filter(
            db.or_(
                Part.name.ilike(f'%{q}%'),
                Part.article.ilike(f'%{q}%'),
                Part.catalog_number.ilike(f'%{q}%'),
                Part.applicability.ilike(f'%{q}%'),
            )
        )
    if category_id:
        query = query.filter_by(category_id=category_id)

    parts = query.order_by(Part.name).all()
    categories = Category.query.order_by(Category.name).all()
    return render_template('catalog.html', parts=parts, categories=categories,
                           q=q, selected_category=category_id)


@app.route('/catalog/add', methods=['POST'])
@login_required
@role_required('admin', 'manager', 'storekeeper')
def add_part():
    article = request.form.get('article', '').strip()
    if Part.query.filter_by(article=article).first():
        flash(f'Артикул {article} уже существует', 'error')
        return redirect(url_for('catalog'))

    part = Part(
        article=article,
        catalog_number=request.form.get('catalog_number', '').strip(),
        name=request.form.get('name', '').strip(),
        manufacturer=request.form.get('manufacturer', '').strip(),
        category_id=request.form.get('category_id', type=int),
        price=float(request.form.get('price', 0) or 0),
        quantity=int(request.form.get('quantity', 0) or 0),
        min_quantity=int(request.form.get('min_quantity', 5) or 5),
        applicability=request.form.get('applicability', '').strip(),
        analogs=request.form.get('analogs', '').strip(),
    )
    db.session.add(part)
    db.session.commit()
    flash(f'Товар «{part.name}» добавлен в каталог', 'success')
    return redirect(url_for('catalog'))


@app.route('/inventory')
@login_required
def inventory():
    operations = Operation.query.order_by(Operation.created_at.desc()).limit(100).all()
    parts = Part.query.order_by(Part.name).all()
    return render_template('inventory.html', operations=operations, parts=parts)


@app.route('/inventory/operation', methods=['POST'])
@login_required
@role_required('admin', 'manager', 'storekeeper')
def add_operation():
    op_type = request.form.get('op_type')
    part_id = request.form.get('part_id', type=int)
    quantity = int(request.form.get('quantity', 0) or 0)
    comment = request.form.get('comment', '').strip()

    part = Part.query.get_or_404(part_id)

    if op_type in ('sale', 'writeoff') and part.quantity < quantity:
        flash(f'Недостаточно товара. Доступно: {part.quantity}', 'error')
        return redirect(url_for('inventory'))

    if op_type in ('receipt', 'transfer'):
        part.quantity += quantity
    else:
        part.quantity -= quantity

    op = Operation(op_type=op_type, part_id=part_id, quantity=quantity,
                   comment=comment, user_id=session.get('user_id'))
    db.session.add(op)
    db.session.commit()

    labels = {'receipt': 'Поступление', 'sale': 'Реализация',
              'writeoff': 'Списание', 'transfer': 'Перемещение'}
    flash(f'{labels.get(op_type, op_type)}: {part.name} × {quantity}', 'success')
    return redirect(url_for('inventory'))


@app.route('/orders')
@login_required
def orders():
    orders_list = Order.query.order_by(Order.created_at.desc()).all()
    customers = Customer.query.order_by(Customer.full_name).all()
    parts = Part.query.order_by(Part.name).all()
    return render_template('orders.html', orders=orders_list,
                           customers=customers, parts=parts)


@app.route('/orders/create', methods=['POST'])
@login_required
@role_required('admin', 'manager')
def create_order():
    customer_id = request.form.get('customer_id', type=int)
    part_id = request.form.get('part_id', type=int)
    quantity = int(request.form.get('quantity', 1) or 1)

    if not customer_id or not part_id:
        flash('Укажите покупателя и товар', 'error')
        return redirect(url_for('orders'))

    part = Part.query.get_or_404(part_id)
    customer = Customer.query.get_or_404(customer_id)

    order = Order(customer_id=customer.id, status='новый',
                  total=part.price * quantity)
    db.session.add(order)
    db.session.flush()

    item = OrderItem(order_id=order.id, part_id=part.id,
                     quantity=quantity, price=part.price)
    db.session.add(item)
    db.session.commit()

    flash(f'Заказ №{order.id} создан для {customer.full_name}', 'success')
    return redirect(url_for('orders'))


@app.route('/orders/<int:order_id>/status', methods=['POST'])
@login_required
@role_required('admin', 'manager')
def update_order_status(order_id):
    order = Order.query.get_or_404(order_id)
    new_status = request.form.get('status')
    order.status = new_status

    if new_status == 'выдан':
        for item in order.items:
            item.part.quantity -= item.quantity
            op = Operation(op_type='sale', part_id=item.part_id,
                           quantity=item.quantity,
                           comment=f'Заказ №{order.id}',
                           user_id=session.get('user_id'))
            db.session.add(op)

    db.session.commit()
    flash(f'Статус заказа №{order.id} изменён на «{new_status}»', 'success')
    return redirect(url_for('orders'))


@app.route('/settlements')
@login_required
def settlements():
    customers = Customer.query.order_by(Customer.full_name).all()
    total_debt = db.session.query(db.func.sum(Customer.debt)).scalar() or 0.0
    return render_template('settlements.html',
                           customers=customers, total_debt=total_debt)


@app.route('/reports')
@login_required
def reports():
    sales = (db.session.query(Part, db.func.sum(OrderItem.quantity).label('qty'),
                              db.func.sum(OrderItem.quantity * OrderItem.price).label('revenue'))
             .join(OrderItem, OrderItem.part_id == Part.id)
             .join(Order, Order.id == OrderItem.order_id)
             .filter(Order.status == 'выдан')
             .group_by(Part.id)
             .order_by(db.desc('revenue'))
             .all())

    total_revenue = sum(s.revenue or 0 for s in sales) or 1.0
    abc = []
    cumulative = 0.0
    for s in sales:
        share = (s.revenue or 0) / total_revenue * 100
        cumulative += share
        if cumulative <= 80:
            group = 'A'
        elif cumulative <= 95:
            group = 'B'
        else:
            group = 'C'
        abc.append({'part': s.Part, 'qty': s.qty, 'revenue': s.revenue,
                    'share': round(share, 2), 'group': group})

    low_stock = Part.query.filter(Part.quantity <= Part.min_quantity).all()
    since = datetime.utcnow() - timedelta(days=30)
    operations = (Operation.query
                  .filter(Operation.created_at >= since)
                  .order_by(Operation.created_at.desc()).all())

    return render_template('reports.html', abc=abc, low_stock=low_stock,
                           operations=operations, total_revenue=total_revenue)


# ---------------------------------------------------------------------------
# ИНИЦИАЛИЗАЦИЯ БД И ДЕМО-ДАННЫХ
# ---------------------------------------------------------------------------

def init_db():
    with app.app_context():
        db.create_all()

        if User.query.count() == 0:
            admin = User(username='admin', full_name='Администратор', role='admin')
            admin.set_password('admin123')
            manager = User(username='manager', full_name='Иванов И.И.', role='manager')
            manager.set_password('manager123')
            storekeeper = User(username='sklad', full_name='Петров П.П.', role='storekeeper')
            storekeeper.set_password('sklad123')
            db.session.add_all([admin, manager, storekeeper])

        if Category.query.count() == 0:
            for name in ['Запчасти двигателя', 'Тормозная система',
                         'Подвеска', 'Автохимия', 'Аксессуары', 'Шины и диски']:
                db.session.add(Category(name=name))
        db.session.commit()

        if Part.query.count() == 0:
            cat_map = {c.name: c.id for c in Category.query.all()}
            demo_parts = [
                ('A-1001', '90919-01253', 'Свеча зажигания NGK', 'NGK', 'Запчасти двигателя', 450.0, 120, 20, 'Toyota Camry 2.5; Lexus RX', 'Denso IK20'),
                ('A-1002', '04465-33471', 'Колодки тормозные передние', 'Toyota', 'Тормозная система', 3200.0, 40, 10, 'Toyota Camry 2011-2017', 'Advics A1N050'),
                ('A-1003', '31356780847', 'Стойка амортизатора передняя', 'BMW', 'Подвеска', 8900.0, 12, 4, 'BMW X3 F25', 'Sachs 315 176'),
                ('A-1004', 'G-052-145-A2', 'Масло моторное 5W-30 (1 л)', 'VW', 'Автохимия', 890.0, 200, 50, 'Универсальное', 'Mobil 1, Castrol EDGE'),
                ('A-1005', 'KE-9001', 'Коврики резиновые 4 шт.', 'Rezaw-Plast', 'Аксессуары', 2400.0, 35, 8, 'Lada Vesta, XRAY', '—'),
                ('A-1006', '205/55R16', 'Шина летняя 205/55 R16', 'Michelin', 'Шины и диски', 7200.0, 24, 8, 'Универсальная', 'Nokian, Continental'),
                ('A-1007', 'A-2001', 'Фильтр воздушный', 'Mann', 'Запчасти двигателя', 650.0, 3, 10, 'Kia Rio, Hyundai Solaris', 'Bosch F026400'),
            ]
            for art, cat_num, name, mfr, cat, price, qty, minq, appl, analogs in demo_parts:
                db.session.add(Part(article=art, catalog_number=cat_num, name=name,
                                    manufacturer=mfr, category_id=cat_map.get(cat),
                                    price=price, quantity=qty, min_quantity=minq,
                                    applicability=appl, analogs=analogs))

            db.session.add_all([
                Customer(full_name='ООО «АвтоТранс»', phone='+7 900 111-22-33',
                         email='info@autotrans.ru', debt=0.0),
                Customer(full_name='Сидоров А.В.', phone='+7 900 444-55-66',
                         email='sidorov@mail.ru', debt=1200.0),
                Customer(full_name='ИП Кузнецов', phone='+7 900 777-88-99',
                         email='kuznecov@bk.ru', debt=0.0),
            ])
            db.session.commit()


# ---------------------------------------------------------------------------
# ЗАПУСК
# ---------------------------------------------------------------------------

if __name__ == '__main__':
    init_db()
    print('=' * 60)
    print('  АСУ «АвтоЗапчасти» — система управления магазином')
    print('  Откройте http://127.0.0.1:5000')
    print('=' * 60)
    print('  Демо-доступ:')
    print('    admin / admin123        — администратор')
    print('    manager / manager123    — менеджер')
    print('    sklad / sklad123        — кладовщик')
    print('=' * 60)
    app.run(debug=True, host='0.0.0.0', port=5050)