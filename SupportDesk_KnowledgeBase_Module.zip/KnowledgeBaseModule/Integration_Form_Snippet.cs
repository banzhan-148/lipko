// Пример обработчика кнопки в MainUserForm / MainWorkerForm / MainAdminForm:

private void ExpUIButtonKnowledgeBase_Click(object sender, EventArgs e)
{
    // Можно открыть standalone, или встроенную форму
    // Вариант 1: запустить внешний exe (если лежит рядом)
    // System.Diagnostics.Process.Start("KnowledgeBase.exe");

    // Вариант 2: встроенная форма (после добавления KnowledgeBaseForm в проект)
    Form fKb = new KnowledgeBaseForm(); // или forms.KnowledgeBaseForm
    fKb.Show();
    fKb.FormClosed += new FormClosedEventHandler(MainForm_FormClosed);
    Hide();
}
