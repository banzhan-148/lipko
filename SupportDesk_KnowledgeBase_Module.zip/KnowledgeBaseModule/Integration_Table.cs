// Добавьте в Program.cs в регион #region Таблицы (рядом с Table_contacts)

    internal static class Table_knowledge
    {
        public static string main = "KnowledgeBase";
        public static string id = "ID";
        public static string title = "Title";
        public static string category = "Category";
        public static string problem = "Problem";
        public static string solution = "Solution";
        public static string keywords = "Keywords";
        public static string createdBy = "CreatedBy";
        public static string createdDate = "CreatedDate";
        public static string views = "Views";
    }
