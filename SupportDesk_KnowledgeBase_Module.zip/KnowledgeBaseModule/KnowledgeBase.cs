using System;
using System.Data;
using System.Data.SQLite;
using System.Drawing;
using System.Windows.Forms;
using System.IO;

namespace KnowledgeBaseModule
{
    public class Program
    {
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new MainForm());
        }
    }

    public class MainForm : Form
    {
        private SQLiteConnection db;
        private DataGridView grid;
        private TextBox searchBox;
        private ComboBox categoryBox;
        private TextBox solutionBox;
        private Label titleLabel;
        private Button copyBtn;
        private Button refreshBtn;
        private Button addBtn;
        private Button deleteBtn;
        private string connectionString = "Data Source=teh_db.db;Version=3;";
        private int selectedId = -1;

        public MainForm()
        {
            this.Text = "База знаний — SupportDesk FAQ / Типовые решения";
            this.Size = new Size(1000, 700);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.MinimumSize = new Size(800, 500);
            this.BackColor = Color.FromArgb(245, 247, 250);
            this.Font = new Font("Segoe UI", 9.5F);

            // Header
            Panel header = new Panel { Dock = DockStyle.Top, Height = 60, BackColor = Color.FromArgb(41, 98, 255) };
            Label headerLabel = new Label {
                Text = "📚  База знаний (FAQ / Типовые решения)",
                ForeColor = Color.White,
                Font = new Font("Segoe UI", 16F, FontStyle.Bold),
                AutoSize = true,
                Location = new Point(20, 15)
            };
            header.Controls.Add(headerLabel);
            this.Controls.Add(header);

            // Search panel
            Panel searchPanel = new Panel { Dock = DockStyle.Top, Height = 50, Padding = new Padding(10) };
            searchBox = new TextBox {
                Width = 350,
                Height = 28,
                Location = new Point(15, 12),
                Font = new Font("Segoe UI", 10F)
            };
            searchBox.TextChanged += (s, e) => LoadData();
            Label searchLbl = new Label { Text = "Поиск:", Location = new Point(15, -2), AutoSize = true, ForeColor = Color.Gray };
            
            categoryBox = new ComboBox {
                Width = 180,
                Location = new Point(380, 12),
                DropDownStyle = ComboBoxStyle.DropDownList,
                Font = new Font("Segoe UI", 10F)
            };
            categoryBox.Items.AddRange(new object[] { "Все категории", "Принтеры", "Сеть", "1С и ПО", "Учетные записи", "Оборудование / ПО", "Другое" });
            categoryBox.SelectedIndex = 0;
            categoryBox.SelectedIndexChanged += (s, e) => LoadData();

            refreshBtn = new Button {
                Text = "🔄 Обновить",
                Location = new Point(580, 10),
                Size = new Size(110, 30),
                FlatStyle = FlatStyle.Flat,
                BackColor = Color.FromArgb(41, 98, 255),
                ForeColor = Color.White
            };
            refreshBtn.Click += (s, e) => LoadData();

            addBtn = new Button {
                Text = "➕ Добавить",
                Location = new Point(700, 10),
                Size = new Size(110, 30),
                FlatStyle = FlatStyle.Flat,
                BackColor = Color.FromArgb(46, 125, 50),
                ForeColor = Color.White
            };
            addBtn.Click += AddBtn_Click;

            deleteBtn = new Button {
                Text = "🗑 Удалить",
                Location = new Point(820, 10),
                Size = new Size(100, 30),
                FlatStyle = FlatStyle.Flat,
                BackColor = Color.FromArgb(198, 40, 40),
                ForeColor = Color.White
            };
            deleteBtn.Click += DeleteBtn_Click;

            searchPanel.Controls.AddRange(new Control[] { searchBox, categoryBox, refreshBtn, addBtn, deleteBtn });
            this.Controls.Add(searchPanel);

            // Split
            SplitContainer split = new SplitContainer {
                Dock = DockStyle.Fill,
                Orientation = Orientation.Horizontal,
                SplitterDistance = 280,
                BackColor = Color.White
            };

            // Grid
            grid = new DataGridView {
                Dock = DockStyle.Fill,
                AllowUserToAddRows = false,
                AllowUserToDeleteRows = false,
                ReadOnly = true,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                MultiSelect = false,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
                RowHeadersVisible = false,
                BackgroundColor = Color.White,
                BorderStyle = BorderStyle.None,
                Font = new Font("Segoe UI", 9.5F),
                ColumnHeadersDefaultCellStyle = new DataGridViewCellStyle {
                    BackColor = Color.FromArgb(240, 242, 245),
                    Font = new Font("Segoe UI", 9.5F, FontStyle.Bold),
                    Padding = new Padding(5)
                },
                EnableHeadersVisualStyles = false
            };
            grid.Columns.Add("ID", "ID");
            grid.Columns.Add("Title", "Название / Проблема");
            grid.Columns.Add("Category", "Категория");
            grid.Columns.Add("Views", "Просмотры");
            grid.Columns["ID"].Visible = false;
            grid.Columns["Views"].Width = 80;
            grid.Columns["Category"].Width = 140;
            grid.SelectionChanged += Grid_SelectionChanged;
            grid.CellDoubleClick += (s, e) => { if (selectedId > 0) IncrementViews(); };

            split.Panel1.Controls.Add(grid);

            // Solution panel
            Panel solPanel = new Panel { Dock = DockStyle.Fill, Padding = new Padding(15) };
            titleLabel = new Label {
                Dock = DockStyle.Top,
                Height = 35,
                Font = new Font("Segoe UI", 12F, FontStyle.Bold),
                ForeColor = Color.FromArgb(30, 30, 30),
                Text = "Выберите запись в списке"
            };
            solutionBox = new TextBox {
                Dock = DockStyle.Fill,
                Multiline = true,
                ScrollBars = ScrollBars.Vertical,
                ReadOnly = true,
                Font = new Font("Consolas", 10F),
                BackColor = Color.FromArgb(250, 250, 252),
                BorderStyle = BorderStyle.FixedSingle
            };
            copyBtn = new Button {
                Text = "📋 Копировать решение в буфер обмена",
                Dock = DockStyle.Bottom,
                Height = 40,
                FlatStyle = FlatStyle.Flat,
                BackColor = Color.FromArgb(41, 98, 255),
                ForeColor = Color.White,
                Font = new Font("Segoe UI", 10F, FontStyle.Bold)
            };
            copyBtn.Click += (s, e) => {
                if (!string.IsNullOrEmpty(solutionBox.Text))
                {
                    Clipboard.SetText(solutionBox.Text);
                    MessageBox.Show("Решение скопировано в буфер обмена!\nМожно вставить в ответ на заявку (Ctrl+V).", "Готово", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            };

            solPanel.Controls.Add(solutionBox);
            solPanel.Controls.Add(copyBtn);
            solPanel.Controls.Add(titleLabel);
            split.Panel2.Controls.Add(solPanel);

            this.Controls.Add(split);

            // Status
            Label status = new Label {
                Dock = DockStyle.Bottom,
                Height = 25,
                Text = "  Подсказка: пользователь сначала смотрит сюда → если не помогло — создаёт заявку. Техник копирует решение в ответ.",
                ForeColor = Color.Gray,
                BackColor = Color.FromArgb(240, 242, 245)
            };
            this.Controls.Add(status);

            // Init DB
            try
            {
                string dbPath = FindDb();
                if (dbPath != null)
                {
                    connectionString = $"Data Source={dbPath};Version=3;";
                    db = new SQLiteConnection(connectionString);
                    db.Open();
                    EnsureTable();
                    LoadData();
                }
                else
                {
                    MessageBox.Show("Файл teh_db.db не найден рядом с программой.\nПоложите exe рядом с базой SupportDesk.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка подключения к БД: " + ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private string FindDb()
        {
            string[] candidates = {
                "teh_db.db",
                Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "teh_db.db"),
                Path.Combine(Directory.GetCurrentDirectory(), "teh_db.db"),
                Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "..", "teh_db.db")
            };
            foreach (var c in candidates)
                if (File.Exists(c)) return Path.GetFullPath(c);
            return null;
        }

        private void EnsureTable()
        {
            using (var cmd = new SQLiteCommand(@"
                CREATE TABLE IF NOT EXISTS KnowledgeBase (
                    ID INTEGER PRIMARY KEY AUTOINCREMENT,
                    Title TEXT NOT NULL,
                    Category TEXT NOT NULL,
                    Problem TEXT,
                    Solution TEXT NOT NULL,
                    Keywords TEXT,
                    CreatedBy TEXT DEFAULT 'System',
                    CreatedDate TEXT,
                    Views INTEGER DEFAULT 0
                );", db))
            {
                cmd.ExecuteNonQuery();
            }
        }

        private void LoadData()
        {
            if (db == null || db.State != ConnectionState.Open) return;
            grid.Rows.Clear();
            string sql = "SELECT ID, Title, Category, Views FROM KnowledgeBase WHERE 1=1";
            if (categoryBox.SelectedIndex > 0)
                sql += " AND Category = @cat";
            if (!string.IsNullOrWhiteSpace(searchBox.Text))
                sql += " AND (Title LIKE @q OR Keywords LIKE @q OR Problem LIKE @q OR Solution LIKE @q)";
            sql += " ORDER BY Views DESC, Title";

            using (var cmd = new SQLiteCommand(sql, db))
            {
                if (categoryBox.SelectedIndex > 0)
                    cmd.Parameters.AddWithValue("@cat", categoryBox.SelectedItem.ToString());
                if (!string.IsNullOrWhiteSpace(searchBox.Text))
                    cmd.Parameters.AddWithValue("@q", "%" + searchBox.Text.Trim() + "%");

                using (var reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        grid.Rows.Add(reader["ID"], reader["Title"], reader["Category"], reader["Views"]);
                    }
                }
            }
            selectedId = -1;
            titleLabel.Text = "Выберите запись в списке";
            solutionBox.Text = "";
        }

        private void Grid_SelectionChanged(object sender, EventArgs e)
        {
            if (grid.SelectedRows.Count == 0) return;
            selectedId = Convert.ToInt32(grid.SelectedRows[0].Cells["ID"].Value);
            using (var cmd = new SQLiteCommand("SELECT Title, Problem, Solution FROM KnowledgeBase WHERE ID=@id", db))
            {
                cmd.Parameters.AddWithValue("@id", selectedId);
                using (var r = cmd.ExecuteReader())
                {
                    if (r.Read())
                    {
                        titleLabel.Text = r["Title"].ToString();
                        string problem = r["Problem"]?.ToString() ?? "";
                        string solution = r["Solution"]?.ToString() ?? "";
                        solutionBox.Text = (string.IsNullOrEmpty(problem) ? "" : "ПРОБЛЕМА:\n" + problem + "\n\n") + "РЕШЕНИЕ:\n" + solution;
                    }
                }
            }
        }

        private void IncrementViews()
        {
            if (selectedId <= 0) return;
            using (var cmd = new SQLiteCommand("UPDATE KnowledgeBase SET Views = Views + 1 WHERE ID=@id", db))
            {
                cmd.Parameters.AddWithValue("@id", selectedId);
                cmd.ExecuteNonQuery();
            }
            LoadData();
        }

        private void AddBtn_Click(object sender, EventArgs e)
        {
            using (var f = new AddForm())
            {
                if (f.ShowDialog() == DialogResult.OK)
                {
                    using (var cmd = new SQLiteCommand(@"
                        INSERT INTO KnowledgeBase (Title, Category, Problem, Solution, Keywords, CreatedBy, CreatedDate)
                        VALUES (@t, @c, @p, @s, @k, @by, @dt)", db))
                    {
                        cmd.Parameters.AddWithValue("@t", f.Title);
                        cmd.Parameters.AddWithValue("@c", f.Category);
                        cmd.Parameters.AddWithValue("@p", f.Problem);
                        cmd.Parameters.AddWithValue("@s", f.Solution);
                        cmd.Parameters.AddWithValue("@k", f.Keywords);
                        cmd.Parameters.AddWithValue("@by", Environment.UserName);
                        cmd.Parameters.AddWithValue("@dt", DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"));
                        cmd.ExecuteNonQuery();
                    }
                    LoadData();
                }
            }
        }

        private void DeleteBtn_Click(object sender, EventArgs e)
        {
            if (selectedId <= 0)
            {
                MessageBox.Show("Выберите запись для удаления.", "Внимание", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            if (MessageBox.Show("Удалить выбранную запись из базы знаний?", "Подтверждение", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                using (var cmd = new SQLiteCommand("DELETE FROM KnowledgeBase WHERE ID=@id", db))
                {
                    cmd.Parameters.AddWithValue("@id", selectedId);
                    cmd.ExecuteNonQuery();
                }
                LoadData();
            }
        }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            db?.Close();
            base.OnFormClosing(e);
        }
    }

    public class AddForm : Form
    {
        public string Title { get; private set; }
        public string Category { get; private set; }
        public string Problem { get; private set; }
        public string Solution { get; private set; }
        public string Keywords { get; private set; }

        private TextBox tbTitle, tbProblem, tbSolution, tbKeywords;
        private ComboBox cbCat;

        public AddForm()
        {
            this.Text = "Добавить типовое решение";
            this.Size = new Size(550, 520);
            this.StartPosition = FormStartPosition.CenterParent;
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.Font = new Font("Segoe UI", 9.5F);

            int y = 15;
            AddLabel("Название / проблема:", 15, y); y += 22;
            tbTitle = new TextBox { Location = new Point(15, y), Width = 500 }; y += 35;

            AddLabel("Категория:", 15, y); y += 22;
            cbCat = new ComboBox {
                Location = new Point(15, y), Width = 250,
                DropDownStyle = ComboBoxStyle.DropDownList
            };
            cbCat.Items.AddRange(new object[] { "Принтеры", "Сеть", "1С и ПО", "Учетные записи", "Оборудование / ПО", "Другое" });
            cbCat.SelectedIndex = 0; y += 40;

            AddLabel("Краткое описание проблемы:", 15, y); y += 22;
            tbProblem = new TextBox { Location = new Point(15, y), Width = 500, Height = 60, Multiline = true, ScrollBars = ScrollBars.Vertical }; y += 75;

            AddLabel("Решение (пошагово):", 15, y); y += 22;
            tbSolution = new TextBox { Location = new Point(15, y), Width = 500, Height = 120, Multiline = true, ScrollBars = ScrollBars.Vertical }; y += 135;

            AddLabel("Ключевые слова (через пробел, для поиска):", 15, y); y += 22;
            tbKeywords = new TextBox { Location = new Point(15, y), Width = 500 }; y += 45;

            Button ok = new Button {
                Text = "Сохранить",
                DialogResult = DialogResult.OK,
                Location = new Point(300, y),
                Size = new Size(100, 32),
                BackColor = Color.FromArgb(46, 125, 50),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat
            };
            ok.Click += (s, e) => {
                if (string.IsNullOrWhiteSpace(tbTitle.Text) || string.IsNullOrWhiteSpace(tbSolution.Text))
                {
                    MessageBox.Show("Заполните название и решение.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    this.DialogResult = DialogResult.None;
                    return;
                }
                Title = tbTitle.Text.Trim();
                Category = cbCat.SelectedItem.ToString();
                Problem = tbProblem.Text.Trim();
                Solution = tbSolution.Text.Trim();
                Keywords = tbKeywords.Text.Trim();
            };

            Button cancel = new Button {
                Text = "Отмена",
                DialogResult = DialogResult.Cancel,
                Location = new Point(415, y),
                Size = new Size(100, 32)
            };

            this.Controls.AddRange(new Control[] { tbTitle, cbCat, tbProblem, tbSolution, tbKeywords, ok, cancel });
            this.AcceptButton = ok;
            this.CancelButton = cancel;
        }

        private void AddLabel(string text, int x, int y)
        {
            this.Controls.Add(new Label { Text = text, Location = new Point(x, y), AutoSize = true, ForeColor = Color.FromArgb(60, 60, 60) });
        }
    }
}
