Модуль «База знаний» добавлен.

Содержимое архива SupportDesk_KnowledgeBase_Module.zip:

KnowledgeBaseModule/
  KnowledgeBase.exe     ← ГОТОВЫЙ ФАЙЛ ДЛЯ ЗАПУСКА
  KnowledgeBase.cs      ← исходник
  teh_db.db             ← база с таблицей KnowledgeBase + 6 примеров
  System.Data.SQLite.dll
  SQLite.Interop.dll
  x64/  x86/
  README.txt
  Integration_Table.cs
  Integration_Form_Snippet.cs

КАК ПОЛЬЗОВАТЬСЯ ПРЯМО СЕЙЧАС:
1. Распакуйте архив.
2. Запустите KnowledgeBase.exe (нужен Windows + .NET Framework 4.x, который уже есть в системе).
3. Или скопируйте KnowledgeBase.exe + dll + x64 + x86 + teh_db.db в папку bin\Release вашего SupportDesk и запускайте оттуда.

Таблица KnowledgeBase уже создана в БД. Основное приложение SupportDesk продолжит работать как раньше.
