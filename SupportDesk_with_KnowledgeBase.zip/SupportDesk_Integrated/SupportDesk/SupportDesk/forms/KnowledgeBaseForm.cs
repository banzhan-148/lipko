using System;
using System.Collections.Generic;
using System.Data.SQLite;
using System.Drawing;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace SupportDesk.forms
{
    public partial class KnowledgeBaseForm : Form
    {
        #region Настройка формы
        public const int WM_NCLBUTTONDOWN = 0xA1;
        public const int HT_CAPTION = 0x2;
        [DllImport("user32.dll")]
        public static extern int SendMessage(IntPtr hWnd, int Msg, int wParam, int lParam);
        [DllImport("user32.dll")]
        public static extern bool ReleaseCapture();
        #endregion

        private SQLiteConnection DB;
        private DataGridView dataGridViewKB;
        private TextBox textBoxSearch;
        private ComboBox comboBoxCategory;
        private TextBox textBoxSolution;
        private Label labelTitle;
        private Button buttonCopy;
        private Button buttonAdd;
        private Button buttonDelete;
        private Button buttonRefresh;
        private Button buttonExit;
        private Button buttonCreateTicket;
        private int selectedId = -1;
        private Panel panelTop;
        private Panel panelBottom;
        private SplitContainer splitContainer1;

        [Obsolete]
        public KnowledgeBaseForm()
        {
            InitializeComponentCustom();
        }

        private void InitializeComponentCustom()
        {
            this.Text = "База знаний — FAQ / Типовые решения";
            this.ClientSize = new Size(980, 640);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.FormBorderStyle = FormBorderStyle.None;
            this.BackColor = Color.White;
            this.MinimumSize = new Size(800, 500);

            // Top bar (drag + title + close)
            panelTop = new Panel
            {
                Dock = DockStyle.Top,
                Height = 42,
                BackColor = Color.FromArgb(0, 116, 228)
            };
            panelTop.MouseDown += FormControl;

            Label lblHeader = new Label
            {
                Text = "📚  База знаний (FAQ / Типовые решения)",
                ForeColor = Color.White,
                Font = new Font("Arial", 12F, FontStyle.Bold),
                AutoSize = true,
                Location = new Point(12, 11)
            };
            lblHeader.MouseDown += FormControl;
            panelTop.Controls.Add(lblHeader);

            buttonExit = new Button
            {
                Text = "✕",
                FlatStyle = FlatStyle.Flat,
                ForeColor = Color.White,
                BackColor = Color.Transparent,
                Font = new Font("Arial", 12F, FontStyle.Bold),
                Size = new Size(40, 40),
                Location = new Point(this.ClientSize.Width - 45, 1),
                Anchor = AnchorStyles.Top | AnchorStyles.Right,
                Cursor = Cursors.Hand
            };
            buttonExit.FlatAppearance.BorderSize = 0;
            buttonExit.Click += ButtonExit_Click;
            panelTop.Controls.Add(buttonExit);

            // Search panel
            Panel searchPanel = new Panel
            {
                Dock = DockStyle.Top,
                Height = 48,
                BackColor = Color.FromArgb(245, 247, 250),
                Padding = new Padding(8)
            };

            textBoxSearch = new TextBox
            {
                Width = 280,
                Location = new Point(12, 12),
                Font = new Font("Arial", 10F)
            };
            textBoxSearch.TextChanged += (s, e) => FullList();

            comboBoxCategory = new ComboBox
            {
                Width = 160,
                Location = new Point(300, 11),
                DropDownStyle = ComboBoxStyle.DropDownList,
                Font = new Font("Arial", 10F)
            };
            comboBoxCategory.Items.AddRange(new object[] {
                "Все категории", "Принтеры", "Сеть", "1С и ПО",
                "Учетные записи", "Оборудование / ПО", "Другое"
            });
            comboBoxCategory.SelectedIndex = 0;
            comboBoxCategory.SelectedIndexChanged += (s, e) => FullList();

            buttonRefresh = CreateFlatButton("🔄 Обновить", 480, 8, 110, Color.FromArgb(0, 116, 228));
            buttonRefresh.Click += (s, e) => FullList();

            buttonAdd = CreateFlatButton("➕ Добавить", 600, 8, 110, Color.FromArgb(46, 125, 50));
            buttonAdd.Click += ButtonAdd_Click;

            buttonDelete = CreateFlatButton("🗑 Удалить", 720, 8, 100, Color.FromArgb(198, 40, 40));
            buttonDelete.Click += ButtonDelete_Click;

            searchPanel.Controls.AddRange(new Control[] {
                textBoxSearch, comboBoxCategory, buttonRefresh, buttonAdd, buttonDelete
            });

            // Split
            splitContainer1 = new SplitContainer
            {
                Dock = DockStyle.Fill,
                Orientation = Orientation.Horizontal,
                SplitterDistance = 260,
                BackColor = Color.White
            };

            dataGridViewKB = new DataGridView
            {
                Dock = DockStyle.Fill,
                AllowUserToAddRows = false,
                AllowUserToDeleteRows = false,
                ReadOnly = true,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                MultiSelect = false,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
                RowHeadersVisible = false,
                BackgroundColor = Color.White,
                BorderStyle = BorderStyle.None,
                Font = new Font("Arial", 9.5F),
                EnableHeadersVisualStyles = false
            };
            dataGridViewKB.ColumnHeadersDefaultCellStyle = new DataGridViewCellStyle
            {
                BackColor = Color.FromArgb(240, 242, 245),
                Font = new Font("Arial", 9.5F, FontStyle.Bold),
                Padding = new Padding(4)
            };
            dataGridViewKB.Columns.Add("ID", "ID");
            dataGridViewKB.Columns.Add("Title", "Название / Проблема");
            dataGridViewKB.Columns.Add("Category", "Категория");
            dataGridViewKB.Columns.Add("Views", "Просмотры");
            dataGridViewKB.Columns["ID"].Visible = false;
            dataGridViewKB.Columns["Views"].FillWeight = 20;
            dataGridViewKB.Columns["Category"].FillWeight = 25;
            dataGridViewKB.SelectionChanged += DataGridViewKB_SelectionChanged;
            dataGridViewKB.CellDoubleClick += (s, e) => IncrementViews();

            splitContainer1.Panel1.Controls.Add(dataGridViewKB);

            // Solution area
            Panel solPanel = new Panel { Dock = DockStyle.Fill, Padding = new Padding(12) };
            labelTitle = new Label
            {
                Dock = DockStyle.Top,
                Height = 32,
                Font = new Font("Arial", 11F, FontStyle.Bold),
                ForeColor = Color.FromArgb(30, 30, 30),
                Text = "Выберите запись в списке"
            };
            textBoxSolution = new TextBox
            {
                Dock = DockStyle.Fill,
                Multiline = true,
                ScrollBars = ScrollBars.Vertical,
                ReadOnly = true,
                Font = new Font("Consolas", 10F),
                BackColor = Color.FromArgb(250, 250, 252),
                BorderStyle = BorderStyle.FixedSingle
            };
            buttonCopy = CreateFlatButton("📋  Копировать решение в буфер обмена", 0, 0, 0, Color.FromArgb(0, 116, 228));
            buttonCopy.Dock = DockStyle.Bottom;
            buttonCopy.Height = 38;
            buttonCopy.Click += ButtonCopy_Click;

            buttonCreateTicket = CreateFlatButton("Не помогло — создать заявку", 0, 0, 0, Color.FromArgb(255, 152, 0));
            buttonCreateTicket.Dock = DockStyle.Bottom;
            buttonCreateTicket.Height = 36;
            buttonCreateTicket.Click += ButtonCreateTicket_Click;

            solPanel.Controls.Add(textBoxSolution);
            solPanel.Controls.Add(buttonCopy);
            solPanel.Controls.Add(buttonCreateTicket);
            solPanel.Controls.Add(labelTitle);
            splitContainer1.Panel2.Controls.Add(solPanel);

            // Bottom status
            panelBottom = new Panel
            {
                Dock = DockStyle.Bottom,
                Height = 26,
                BackColor = Color.FromArgb(240, 242, 245)
            };
            Label status = new Label
            {
                Text = "  Пользователь сначала смотрит сюда → если не помогло — создаёт заявку. Техник копирует решение в ответ.",
                Dock = DockStyle.Fill,
                ForeColor = Color.Gray,
                Font = new Font("Arial", 8.5F),
                TextAlign = ContentAlignment.MiddleLeft
            };
            panelBottom.Controls.Add(status);

            this.Controls.Add(splitContainer1);
            this.Controls.Add(searchPanel);
            this.Controls.Add(panelTop);
            this.Controls.Add(panelBottom);

            this.Load += KnowledgeBaseForm_Load;
            this.Resize += (s, e) => {
                if (buttonExit != null)
                    buttonExit.Location = new Point(this.ClientSize.Width - 45, 1);
            };
        }

        private Button CreateFlatButton(string text, int x, int y, int w, Color back)
        {
            var b = new Button
            {
                Text = text,
                Location = new Point(x, y),
                Size = new Size(w > 0 ? w : 200, 30),
                FlatStyle = FlatStyle.Flat,
                BackColor = back,
                ForeColor = Color.White,
                Font = new Font("Arial", 9F, FontStyle.Bold),
                Cursor = Cursors.Hand
            };
            b.FlatAppearance.BorderSize = 0;
            return b;
        }

        private async void KnowledgeBaseForm_Load(object sender, EventArgs e)
        {
            DB = new SQLiteConnection(Database.connectionString);
            await DB.OpenAsync();
            EnsureTable();
            FullList();

            // Только ADMIN и WORKER могут добавлять/удалять
            bool canEdit = DataUsers.GroupUser == "ADMIN" || DataUsers.GroupUser == "WORKER" || DataUsers.GroupUser == "TECH";
            buttonAdd.Visible = canEdit;
            buttonDelete.Visible = canEdit;
        }

        private void EnsureTable()
        {
            try
            {
                using (var cmd = new SQLiteCommand(@"
                    CREATE TABLE IF NOT EXISTS KnowledgeBase (
                        ID INTEGER PRIMARY KEY AUTOINCREMENT,
                        Title TEXT NOT NULL,
                        Category TEXT NOT NULL,
                        Problem TEXT,
                        Solution TEXT NOT NULL,
                        Keywords TEXT,
                        CreatedBy TEXT DEFAULT 'System',
                        CreatedDate TEXT,
                        Views INTEGER DEFAULT 0
                    );", DB))
                {
                    cmd.ExecuteNonQuery();
                }
            }
            catch { /* уже существует */ }
        }

        private async void FullList()
        {
            if (DB == null || DB.State != System.Data.ConnectionState.Open) return;
            dataGridViewKB.Rows.Clear();
            string sql = $"SELECT [{Table_knowledge.id}], [{Table_knowledge.title}], [{Table_knowledge.category}], [{Table_knowledge.views}] FROM [{Table_knowledge.main}] WHERE 1=1";
            if (comboBoxCategory.SelectedIndex > 0)
                sql += $" AND [{Table_knowledge.category}] = @cat";
            if (!string.IsNullOrWhiteSpace(textBoxSearch.Text))
                sql += $" AND ([{Table_knowledge.title}] LIKE @q OR [{Table_knowledge.keywords}] LIKE @q OR [{Table_knowledge.problem}] LIKE @q OR [{Table_knowledge.solution}] LIKE @q)";
            sql += $" ORDER BY [{Table_knowledge.views}] DESC, [{Table_knowledge.title}]";

            SQLiteDataReader reader = null;
            try
            {
                using (var cmd = new SQLiteCommand(sql, DB))
                {
                    if (comboBoxCategory.SelectedIndex > 0)
                        cmd.Parameters.AddWithValue("@cat", comboBoxCategory.SelectedItem.ToString());
                    if (!string.IsNullOrWhiteSpace(textBoxSearch.Text))
                        cmd.Parameters.AddWithValue("@q", "%" + textBoxSearch.Text.Trim() + "%");

                    reader = (SQLiteDataReader)await cmd.ExecuteReaderAsync();
                    while (await reader.ReadAsync())
                    {
                        dataGridViewKB.Rows.Add(
                            reader[Table_knowledge.id],
                            reader[Table_knowledge.title],
                            reader[Table_knowledge.category],
                            reader[Table_knowledge.views]
                        );
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBoxUI.Show(ex.Message, ex.Source, "Error");
            }
            finally
            {
                reader?.Close();
            }
            selectedId = -1;
            labelTitle.Text = "Выберите запись в списке";
            textBoxSolution.Text = "";
        }

        private async void DataGridViewKB_SelectionChanged(object sender, EventArgs e)
        {
            if (dataGridViewKB.SelectedRows.Count == 0) return;
            selectedId = Convert.ToInt32(dataGridViewKB.SelectedRows[0].Cells["ID"].Value);
            SQLiteDataReader reader = null;
            try
            {
                using (var cmd = new SQLiteCommand(
                    $"SELECT [{Table_knowledge.title}], [{Table_knowledge.problem}], [{Table_knowledge.solution}] FROM [{Table_knowledge.main}] WHERE [{Table_knowledge.id}]=@id", DB))
                {
                    cmd.Parameters.AddWithValue("@id", selectedId);
                    reader = (SQLiteDataReader)await cmd.ExecuteReaderAsync();
                    if (await reader.ReadAsync())
                    {
                        labelTitle.Text = reader[Table_knowledge.title].ToString();
                        string problem = reader[Table_knowledge.problem]?.ToString() ?? "";
                        string solution = reader[Table_knowledge.solution]?.ToString() ?? "";
                        textBoxSolution.Text = (string.IsNullOrEmpty(problem) ? "" : "ПРОБЛЕМА:\r\n" + problem + "\r\n\r\n") + "РЕШЕНИЕ:\r\n" + solution;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBoxUI.Show(ex.Message, ex.Source, "Error");
            }
            finally
            {
                reader?.Close();
            }
        }

        private void IncrementViews()
        {
            if (selectedId <= 0) return;
            try
            {
                using (var cmd = new SQLiteCommand(
                    $"UPDATE [{Table_knowledge.main}] SET [{Table_knowledge.views}] = [{Table_knowledge.views}] + 1 WHERE [{Table_knowledge.id}]=@id", DB))
                {
                    cmd.Parameters.AddWithValue("@id", selectedId);
                    cmd.ExecuteNonQuery();
                }
                FullList();
            }
            catch { }
        }

        private void ButtonCopy_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(textBoxSolution.Text))
            {
                MessageBoxUI.Show("Сначала выберите запись.", "База знаний", "Info");
                return;
            }
            Clipboard.SetText(textBoxSolution.Text);
            MessageBoxUI.Show("Решение скопировано в буфер обмена!\nВставьте его в ответ на заявку (Ctrl+V).", "Готово", "Accept");
        }

        private void ButtonAdd_Click(object sender, EventArgs e)
        {
            using (var f = new KnowledgeBaseAddForm())
            {
                if (f.ShowDialog() == DialogResult.OK)
                {
                    try
                    {
                        using (var cmd = new SQLiteCommand($@"
                            INSERT INTO [{Table_knowledge.main}] 
                            ([{Table_knowledge.title}], [{Table_knowledge.category}], [{Table_knowledge.problem}], 
                             [{Table_knowledge.solution}], [{Table_knowledge.keywords}], [{Table_knowledge.createdBy}], [{Table_knowledge.createdDate}])
                            VALUES (@t, @c, @p, @s, @k, @by, @dt)", DB))
                        {
                            cmd.Parameters.AddWithValue("@t", f.TitleValue);
                            cmd.Parameters.AddWithValue("@c", f.CategoryValue);
                            cmd.Parameters.AddWithValue("@p", f.ProblemValue);
                            cmd.Parameters.AddWithValue("@s", f.SolutionValue);
                            cmd.Parameters.AddWithValue("@k", f.KeywordsValue);
                            cmd.Parameters.AddWithValue("@by", DataUsers.Initials ?? Environment.UserName);
                            cmd.Parameters.AddWithValue("@dt", DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"));
                            cmd.ExecuteNonQuery();
                        }
                        FullList();
                        MessageBoxUI.Show("Запись успешно добавлена в базу знаний.", "База знаний", "Accept");
                    }
                    catch (Exception ex)
                    {
                        MessageBoxUI.Show(ex.Message, ex.Source, "Error");
                    }
                }
            }
        }

        private void ButtonDelete_Click(object sender, EventArgs e)
        {
            if (selectedId <= 0)
            {
                MessageBoxUI.Show("Выберите запись для удаления.", "База знаний", "Info");
                return;
            }
            // Простое подтверждение через MessageBoxUI если есть, иначе стандартный
            var result = MessageBox.Show("Удалить выбранную запись из базы знаний?", "Подтверждение",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.Yes)
            {
                try
                {
                    using (var cmd = new SQLiteCommand(
                        $"DELETE FROM [{Table_knowledge.main}] WHERE [{Table_knowledge.id}]=@id", DB))
                    {
                        cmd.Parameters.AddWithValue("@id", selectedId);
                        cmd.ExecuteNonQuery();
                    }
                    FullList();
                }
                catch (Exception ex)
                {
                    MessageBoxUI.Show(ex.Message, ex.Source, "Error");
                }
            }
        }

        [Obsolete]
        private void ButtonCreateTicket_Click(object sender, EventArgs e)
        {
            Form fNewTicket = new CreateNewTicketForm();
            fNewTicket.Show();
            fNewTicket.FormClosed += (s, args) => { /* остаёмся в KB или закрываем */ };
            // Не скрываем текущую форму, чтобы пользователь мог вернуться
        }

        [Obsolete]
        private void ButtonExit_Click(object sender, EventArgs e)
        {
            if (DataUsers.GroupUser == "ADMIN")
            {
                Form fMain = new MainAdminForm();
                fMain.Show();
                fMain.FormClosed += (s, args) => this.Close();
                Hide();
            }
            else if (DataUsers.GroupUser == "USER")
            {
                Form fMain = new MainUserForm();
                fMain.Show();
                fMain.FormClosed += (s, args) => this.Close();
                Hide();
            }
            else
            {
                Form fMain = new MainWorkerForm();
                fMain.Show();
                fMain.FormClosed += (s, args) => this.Close();
                Hide();
            }
        }

        private void FormControl(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                ReleaseCapture();
                SendMessage(Handle, WM_NCLBUTTONDOWN, HT_CAPTION, 0);
            }
        }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            DB?.Close();
            base.OnFormClosing(e);
        }
    }

    /// <summary>
    /// Форма добавления новой записи в базу знаний
    /// </summary>
    public class KnowledgeBaseAddForm : Form
    {
        public string TitleValue { get; private set; }
        public string CategoryValue { get; private set; }
        public string ProblemValue { get; private set; }
        public string SolutionValue { get; private set; }
        public string KeywordsValue { get; private set; }

        private TextBox tbTitle, tbProblem, tbSolution, tbKeywords;
        private ComboBox cbCat;

        public KnowledgeBaseAddForm()
        {
            this.Text = "Добавить типовое решение";
            this.Size = new Size(560, 540);
            this.StartPosition = FormStartPosition.CenterParent;
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.Font = new Font("Arial", 9.5F);
            this.BackColor = Color.White;

            int y = 18;
            AddLabel("Название / проблема:", 18, y); y += 22;
            tbTitle = new TextBox { Location = new Point(18, y), Width = 510 }; y += 38;

            AddLabel("Категория:", 18, y); y += 22;
            cbCat = new ComboBox
            {
                Location = new Point(18, y),
                Width = 250,
                DropDownStyle = ComboBoxStyle.DropDownList
            };
            cbCat.Items.AddRange(new object[] {
                "Принтеры", "Сеть", "1С и ПО", "Учетные записи", "Оборудование / ПО", "Другое"
            });
            cbCat.SelectedIndex = 0;
            y += 42;

            AddLabel("Краткое описание проблемы:", 18, y); y += 22;
            tbProblem = new TextBox
            {
                Location = new Point(18, y),
                Width = 510,
                Height = 60,
                Multiline = true,
                ScrollBars = ScrollBars.Vertical
            };
            y += 75;

            AddLabel("Решение (пошагово):", 18, y); y += 22;
            tbSolution = new TextBox
            {
                Location = new Point(18, y),
                Width = 510,
                Height = 130,
                Multiline = true,
                ScrollBars = ScrollBars.Vertical
            };
            y += 145;

            AddLabel("Ключевые слова (через пробел, для поиска):", 18, y); y += 22;
            tbKeywords = new TextBox { Location = new Point(18, y), Width = 510 }; y += 48;

            Button ok = new Button
            {
                Text = "Сохранить",
                DialogResult = DialogResult.OK,
                Location = new Point(310, y),
                Size = new Size(105, 32),
                BackColor = Color.FromArgb(46, 125, 50),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Arial", 9F, FontStyle.Bold)
            };
            ok.FlatAppearance.BorderSize = 0;
            ok.Click += (s, e) =>
            {
                if (string.IsNullOrWhiteSpace(tbTitle.Text) || string.IsNullOrWhiteSpace(tbSolution.Text))
                {
                    MessageBox.Show("Заполните название и решение.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    this.DialogResult = DialogResult.None;
                    return;
                }
                TitleValue = tbTitle.Text.Trim();
                CategoryValue = cbCat.SelectedItem.ToString();
                ProblemValue = tbProblem.Text.Trim();
                SolutionValue = tbSolution.Text.Trim();
                KeywordsValue = tbKeywords.Text.Trim();
            };

            Button cancel = new Button
            {
                Text = "Отмена",
                DialogResult = DialogResult.Cancel,
                Location = new Point(425, y),
                Size = new Size(100, 32)
            };

            this.Controls.AddRange(new Control[] { tbTitle, cbCat, tbProblem, tbSolution, tbKeywords, ok, cancel });
            this.AcceptButton = ok;
            this.CancelButton = cancel;
        }

        private void AddLabel(string text, int x, int y)
        {
            this.Controls.Add(new Label
            {
                Text = text,
                Location = new Point(x, y),
                AutoSize = true,
                ForeColor = Color.FromArgb(60, 60, 60)
            });
        }
    }
}
