"""
Clean Flask inventory / orders API.

Improvements over the legacy version:
- parameterized queries (no SQL injection)
- single connection per request via context manager + WAL
- no N+1 (LEFT JOIN + GROUP BY)
- proper error handling and validation
- config from environment
- indexes created on seed
"""

from __future__ import annotations

import os
import sqlite3
from contextlib import contextmanager
from typing import Any, Generator

from flask import Flask, jsonify, render_template, request

app = Flask(__name__)
app.config["SECRET_KEY"] = os.environ.get("SECRET_KEY", "dev-only-change-me")
DB_PATH = os.environ.get("DB_PATH", "app.db")


@contextmanager
def get_db() -> Generator[sqlite3.Connection, None, None]:
    """Yield a connection with row factory and sensible pragmas."""
    conn = sqlite3.connect(DB_PATH, timeout=10)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    conn.execute("PRAGMA journal_mode = WAL")
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


def init_schema(conn: sqlite3.Connection) -> None:
    """Create tables and indexes if they do not exist."""
    conn.executescript(
        """
        CREATE TABLE IF NOT EXISTS items (
            id    INTEGER PRIMARY KEY,
            name  TEXT    NOT NULL,
            price REAL    NOT NULL CHECK (price >= 0),
            qty   INTEGER NOT NULL CHECK (qty >= 0)
        );

        CREATE TABLE IF NOT EXISTS orders (
            id         INTEGER PRIMARY KEY AUTOINCREMENT,
            item_id    INTEGER NOT NULL REFERENCES items(id),
            qty        INTEGER NOT NULL CHECK (qty > 0),
            created_at TEXT    NOT NULL DEFAULT (datetime('now'))
        );

        CREATE INDEX IF NOT EXISTS idx_orders_item_id    ON orders(item_id);
        CREATE INDEX IF NOT EXISTS idx_orders_created_at ON orders(created_at);
        """
    )


@app.before_request
def ensure_schema() -> None:
    """Lightweight schema check on first request (safe for concurrent workers)."""
    with get_db() as conn:
        init_schema(conn)


@app.route("/")
def index():
    with get_db() as conn:
        rows = conn.execute(
            "SELECT id, name, price, qty FROM items ORDER BY id"
        ).fetchall()
    items = [dict(r) for r in rows]
    return render_template("index.html", items=items)


@app.route("/api/items")
def api_items():
    """List items with order counts — single query, no N+1."""
    with get_db() as conn:
        rows = conn.execute(
            """
            SELECT
                i.id,
                i.name,
                i.price,
                i.qty,
                COUNT(o.id) AS orders
            FROM items i
            LEFT JOIN orders o ON o.item_id = i.id
            GROUP BY i.id, i.name, i.price, i.qty
            ORDER BY i.id
            """
        ).fetchall()
    return jsonify([dict(r) for r in rows])


@app.route("/api/orders", methods=["POST"])
def create_order():
    data = request.get_json(silent=True)
    if not data or "item_id" not in data or "qty" not in data:
        return jsonify({"ok": False, "error": "item_id and qty are required"}), 400

    try:
        item_id = int(data["item_id"])
        qty = int(data["qty"])
    except (TypeError, ValueError):
        return jsonify({"ok": False, "error": "item_id and qty must be integers"}), 400

    if qty <= 0:
        return jsonify({"ok": False, "error": "qty must be positive"}), 400

    try:
        with get_db() as conn:
            # Ensure item exists
            row = conn.execute(
                "SELECT id FROM items WHERE id = ?", (item_id,)
            ).fetchone()
            if row is None:
                return jsonify({"ok": False, "error": "item not found"}), 404

            cur = conn.execute(
                "INSERT INTO orders (item_id, qty) VALUES (?, ?)",
                (item_id, qty),
            )
            order_id = cur.lastrowid
        return jsonify({"ok": True, "order_id": order_id}), 201
    except sqlite3.Error as exc:
        return jsonify({"ok": False, "error": str(exc)}), 500


@app.route("/api/report")
def report():
    """Aggregate order quantities in a date range."""
    frm = request.args.get("from", "2000-01-01")
    to = request.args.get("to", "2100-01-01")

    # Basic sanity: expect ISO-like dates
    if not (isinstance(frm, str) and isinstance(to, str)):
        return jsonify({"ok": False, "error": "invalid date parameters"}), 400

    with get_db() as conn:
        rows = conn.execute(
            """
            SELECT item_id, SUM(qty) AS total_qty
            FROM orders
            WHERE created_at BETWEEN ? AND ?
            GROUP BY item_id
            """,
            (frm, to),
        ).fetchall()

    by_item = {str(r["item_id"]): r["total_qty"] for r in rows}
    total = sum(by_item.values())
    return jsonify({"total": total, "by_item": by_item})


@app.errorhandler(404)
def not_found(_):
    return jsonify({"ok": False, "error": "not found"}), 404


@app.errorhandler(500)
def internal_error(_):
    return jsonify({"ok": False, "error": "internal server error"}), 500


if __name__ == "__main__":
    import sys

    port = 5001
    if "--port" in sys.argv:
        idx = sys.argv.index("--port")
        if idx + 1 < len(sys.argv):
            port = int(sys.argv[idx + 1])

    debug = os.environ.get("FLASK_DEBUG", "0") == "1"
    app.run(host="127.0.0.1", port=port, debug=debug, threaded=True)
