"""Pytest fixtures: isolated temporary database for every test."""

from __future__ import annotations

import os
import sqlite3

import pytest

# Point the app at a temp DB before importing it
os.environ["DB_PATH"] = ":memory:"  # will be overridden per-test below
os.environ["SECRET_KEY"] = "test-secret"


@pytest.fixture()
def app(tmp_path, monkeypatch):
    db_file = tmp_path / "test.db"
    monkeypatch.setenv("DB_PATH", str(db_file))

    # Import after env is set so module-level DB_PATH is correct
    import importlib
    import app as app_module

    importlib.reload(app_module)

    application = app_module.app
    application.config.update({"TESTING": True})

    # Create schema + minimal seed data
    with app_module.get_db() as conn:
        app_module.init_schema(conn)
        conn.execute(
            "INSERT INTO items (id, name, price, qty) VALUES (1, 'Test Item', 99.5, 10)"
        )
        conn.execute(
            "INSERT INTO items (id, name, price, qty) VALUES (2, 'Another', 42.0, 5)"
        )
        conn.execute(
            "INSERT INTO orders (item_id, qty, created_at) VALUES (1, 3, '2024-06-15')"
        )
        conn.execute(
            "INSERT INTO orders (item_id, qty, created_at) VALUES (1, 2, '2024-07-01')"
        )
        conn.execute(
            "INSERT INTO orders (item_id, qty, created_at) VALUES (2, 1, '2025-01-10')"
        )

    yield application


@pytest.fixture()
def client(app):
    return app.test_client()
