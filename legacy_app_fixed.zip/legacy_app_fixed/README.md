# Legacy App → Fixed

Небольшое Flask-приложение учёта товаров и заказов.

## Что было плохо в legacy

| Проблема | Было | Стало |
|----------|------|-------|
| SQL-инъекции | `f"INSERT ... {item_id}"` | Параметризованные запросы `?` |
| N+1 | Отдельный `COUNT` на каждый товар | Один `LEFT JOIN + GROUP BY` |
| Соединения с БД | Новое на каждый вызов, без WAL | Context manager + `journal_mode=WAL` |
| Обработка ошибок | `except: pass` → 500 без деталей | Валидация + понятные JSON-ответы |
| Секрет | Хардкод в коде | `SECRET_KEY` из окружения |
| Индексы | Нет | `idx_orders_item_id`, `idx_orders_created_at` |
| Тесты | Нет | Полный набор pytest |

## Быстрый старт

```bash
python -m venv .venv
source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -r requirements.txt

python seed.py              # 500 товаров + 5000 заказов
python app.py --port 5001
```

Откройте http://127.0.0.1:5001/

## API

| Метод | URL | Описание |
|-------|-----|----------|
| GET | `/` | HTML-таблица товаров |
| GET | `/api/items` | JSON: товары + кол-во заказов |
| POST | `/api/orders` | Создать заказ `{"item_id": 1, "qty": 3}` |
| GET | `/api/report?from=2024-01-01&to=2024-12-31` | Сумма qty по товарам за период |

## Тесты

```bash
pytest -v --cov=app --cov-report=term-missing
```

## Переменные окружения

- `DB_PATH` — путь к SQLite-файлу (по умолчанию `app.db`)
- `SECRET_KEY` — секрет Flask
- `FLASK_DEBUG=1` — включить debug-режим
