#!/usr/bin/env python3
"""Populate the database with sample items and orders."""

from __future__ import annotations

import datetime
import os
import random
import sqlite3
import sys

DB_PATH = os.environ.get("DB_PATH", "app.db")


def seed(db_path: str = DB_PATH, n_items: int = 500, n_orders: int = 5000) -> None:
    conn = sqlite3.connect(db_path)
    try:
        conn.executescript(
            """
            PRAGMA foreign_keys = ON;
            DROP TABLE IF EXISTS orders;
            DROP TABLE IF EXISTS items;

            CREATE TABLE items (
                id    INTEGER PRIMARY KEY,
                name  TEXT    NOT NULL,
                price REAL    NOT NULL CHECK (price >= 0),
                qty   INTEGER NOT NULL CHECK (qty >= 0)
            );

            CREATE TABLE orders (
                id         INTEGER PRIMARY KEY AUTOINCREMENT,
                item_id    INTEGER NOT NULL REFERENCES items(id),
                qty        INTEGER NOT NULL CHECK (qty > 0),
                created_at TEXT    NOT NULL DEFAULT (datetime('now'))
            );

            CREATE INDEX idx_orders_item_id    ON orders(item_id);
            CREATE INDEX idx_orders_created_at ON orders(created_at);
            """
        )

        items = [
            (f"Товар {i}", round(random.uniform(10, 1000), 2), random.randint(0, 500))
            for i in range(1, n_items + 1)
        ]
        conn.executemany(
            "INSERT INTO items (name, price, qty) VALUES (?, ?, ?)", items
        )

        start = datetime.date(2024, 1, 1)
        orders = [
            (
                random.randint(1, n_items),
                random.randint(1, 10),
                (start + datetime.timedelta(days=random.randint(0, 700))).isoformat(),
            )
            for _ in range(n_orders)
        ]
        conn.executemany(
            "INSERT INTO orders (item_id, qty, created_at) VALUES (?, ?, ?)", orders
        )

        conn.commit()
        print(f"seeded: {n_items} items, {n_orders} orders → {db_path}")
    finally:
        conn.close()


if __name__ == "__main__":
    path = sys.argv[1] if len(sys.argv) > 1 else DB_PATH
    seed(path)
