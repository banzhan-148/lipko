"""Unit & integration tests for the fixed legacy app."""

from __future__ import annotations

import json


def test_index_page(client):
    rv = client.get("/")
    assert rv.status_code == 200
    assert b"Test Item" in rv.data
    assert b"Another" in rv.data


def test_api_items(client):
    rv = client.get("/api/items")
    assert rv.status_code == 200
    data = rv.get_json()
    assert isinstance(data, list)
    assert len(data) == 2

    item1 = next(i for i in data if i["id"] == 1)
    assert item1["name"] == "Test Item"
    assert item1["price"] == 99.5
    assert item1["qty"] == 10
    assert item1["orders"] == 2  # two orders for item 1

    item2 = next(i for i in data if i["id"] == 2)
    assert item2["orders"] == 1


def test_create_order_ok(client):
    rv = client.post(
        "/api/orders",
        data=json.dumps({"item_id": 1, "qty": 4}),
        content_type="application/json",
    )
    assert rv.status_code == 201
    body = rv.get_json()
    assert body["ok"] is True
    assert "order_id" in body

    # order count should increase
    items = client.get("/api/items").get_json()
    item1 = next(i for i in items if i["id"] == 1)
    assert item1["orders"] == 3


def test_create_order_missing_fields(client):
    rv = client.post(
        "/api/orders",
        data=json.dumps({"item_id": 1}),
        content_type="application/json",
    )
    assert rv.status_code == 400
    assert rv.get_json()["ok"] is False


def test_create_order_invalid_qty(client):
    rv = client.post(
        "/api/orders",
        data=json.dumps({"item_id": 1, "qty": 0}),
        content_type="application/json",
    )
    assert rv.status_code == 400


def test_create_order_nonexistent_item(client):
    rv = client.post(
        "/api/orders",
        data=json.dumps({"item_id": 999, "qty": 1}),
        content_type="application/json",
    )
    assert rv.status_code == 404


def test_create_order_sql_injection_safe(client):
    """Legacy used f-strings; this must not crash or inject."""
    rv = client.post(
        "/api/orders",
        data=json.dumps({"item_id": "1; DROP TABLE items;--", "qty": 1}),
        content_type="application/json",
    )
    # should be rejected as non-integer
    assert rv.status_code == 400

    # tables still exist
    items = client.get("/api/items")
    assert items.status_code == 200
    assert len(items.get_json()) == 2


def test_report_full_range(client):
    rv = client.get("/api/report")
    assert rv.status_code == 200
    data = rv.get_json()
    assert data["total"] == 6  # 3+2+1
    assert data["by_item"]["1"] == 5
    assert data["by_item"]["2"] == 1


def test_report_date_filter(client):
    rv = client.get("/api/report?from=2024-01-01&to=2024-12-31")
    data = rv.get_json()
    assert data["total"] == 5  # only the two 2024 orders for item 1
    assert "2" not in data["by_item"]


def test_report_empty_range(client):
    rv = client.get("/api/report?from=1990-01-01&to=1999-12-31")
    data = rv.get_json()
    assert data["total"] == 0
    assert data["by_item"] == {}
