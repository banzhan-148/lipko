"""Наполнение БД тестовыми данными. ВНИМАНИЕ: удаляет существующие данные."""
import datetime
import os
import random
import sqlite3

import db

DB_PATH = os.environ.get(
    "DATABASE", os.path.join(os.path.dirname(os.path.abspath(__file__)), "app.db")
)


def seed(path=DB_PATH, n_items=500, n_orders=5000, rng=None):
    rng = rng or random.Random()
    conn = sqlite3.connect(path)
    conn.executescript("DROP TABLE IF EXISTS orders; DROP TABLE IF EXISTS items;")
    conn.commit()
    conn.close()
    db.init_db(path)

    conn = db.connect(path)
    with conn:
        conn.executemany(
            "INSERT INTO items (name, price, qty) VALUES (?, ?, ?)",
            [(f"Товар {i}", round(rng.uniform(10, 1000), 2), rng.randint(0, 500))
             for i in range(1, n_items + 1)],
        )
        start = datetime.date(2024, 1, 1)
        conn.executemany(
            "INSERT INTO orders (item_id, qty, created_at) VALUES (?, ?, ?)",
            [(rng.randint(1, n_items), rng.randint(1, 10),
              (start + datetime.timedelta(days=rng.randint(0, 700))).isoformat())
             for _ in range(n_orders)],
        )
    conn.close()
    return n_items, n_orders


if __name__ == "__main__":
    items, orders = seed()
    print(f"seeded: {items} items, {orders} orders")
