import os
import sys
from datetime import date

from flask import Flask, g, jsonify, render_template, request

import db

BASE_DIR = os.path.dirname(os.path.abspath(__file__))


def create_app(config=None):
    app = Flask(__name__)
    app.config.update(
        # Секрет берётся из окружения; без него — случайный на время процесса.
        SECRET_KEY=os.environ.get("SECRET_KEY") or os.urandom(32),
        DATABASE=os.environ.get("DATABASE", os.path.join(BASE_DIR, "app.db")),
    )
    if config:
        app.config.update(config)

    db.init_db(app.config["DATABASE"])

    def get_db():
        if "db" not in g:
            g.db = db.connect(app.config["DATABASE"])
        return g.db

    @app.teardown_appcontext
    def close_db(_exc):
        conn = g.pop("db", None)
        if conn is not None:
            conn.close()

    def error(message, status):
        return jsonify({"ok": False, "error": message}), status

    ITEMS_SQL = """
        SELECT i.id, i.name, i.price, i.qty, COUNT(o.id) AS orders
        FROM items i LEFT JOIN orders o ON o.item_id = i.id
        GROUP BY i.id ORDER BY i.id
    """

    @app.route("/")
    def index():
        rows = get_db().execute(ITEMS_SQL).fetchall()
        return render_template("index.html", items=rows)

    @app.route("/api/items")
    def api_items():
        rows = get_db().execute(ITEMS_SQL).fetchall()
        return jsonify([dict(r) for r in rows])

    @app.route("/api/orders", methods=["POST"])
    def create_order():
        data = request.get_json(silent=True)
        if not isinstance(data, dict):
            return error("Тело запроса должно быть JSON-объектом", 400)

        item_id, qty = data.get("item_id"), data.get("qty")
        # bool — подкласс int, его тоже отсекаем
        for value in (item_id, qty):
            if not isinstance(value, int) or isinstance(value, bool):
                return error("item_id и qty должны быть целыми числами", 400)
        if qty <= 0:
            return error("qty должно быть больше нуля", 400)

        conn = get_db()
        try:
            conn.execute("BEGIN IMMEDIATE")
            # Атомарно списываем остаток: условие qty >= ? защищает от гонок
            cur = conn.execute(
                "UPDATE items SET qty = qty - ? WHERE id = ? AND qty >= ?",
                (qty, item_id, qty),
            )
            if cur.rowcount == 0:
                conn.rollback()
                exists = conn.execute(
                    "SELECT 1 FROM items WHERE id = ?", (item_id,)
                ).fetchone()
                if not exists:
                    return error("Товар не найден", 404)
                return error("Недостаточно товара на складе", 409)
            cur = conn.execute(
                "INSERT INTO orders (item_id, qty, created_at) VALUES (?, ?, ?)",
                (item_id, qty, date.today().isoformat()),
            )
            conn.commit()
        except Exception:
            conn.rollback()
            app.logger.exception("Не удалось создать заказ")
            return error("Внутренняя ошибка сервера", 500)
        return jsonify({"ok": True, "order_id": cur.lastrowid}), 201

    def parse_date(value, name):
        try:
            return date.fromisoformat(value).isoformat()
        except ValueError:
            raise ValueError(f"Параметр '{name}' должен быть датой YYYY-MM-DD")

    @app.route("/api/report")
    def report():
        try:
            frm = parse_date(request.args.get("from", "2000-01-01"), "from")
            to = parse_date(request.args.get("to", "2100-01-01"), "to")
        except ValueError as exc:
            return error(str(exc), 400)
        if frm > to:
            return error("Параметр 'from' не может быть позже 'to'", 400)

        rows = get_db().execute(
            """
            SELECT o.item_id, SUM(o.qty) AS qty, SUM(o.qty * i.price) AS revenue
            FROM orders o JOIN items i ON i.id = o.item_id
            WHERE o.created_at BETWEEN ? AND ?
            GROUP BY o.item_id
            """,
            (frm, to),
        ).fetchall()
        return jsonify({
            "total": sum(r["qty"] for r in rows),
            "revenue": round(sum(r["revenue"] for r in rows), 2),
            # ключи JSON — строки; формат by_item сохранён как в старой версии
            "by_item": {str(r["item_id"]): r["qty"] for r in rows},
        })

    return app


if __name__ == "__main__":
    port = 5001
    if "--port" in sys.argv:
        port = int(sys.argv[sys.argv.index("--port") + 1])
    debug = os.environ.get("FLASK_DEBUG") == "1"  # по умолчанию выключен
    create_app().run(host="127.0.0.1", port=port, debug=debug)
